package com.alpha.redtassel.data;

import com.alpha.redtassel.regsiter.RTComboAndSA;
import com.alpha.redtassel.Redtassel;
import com.alpha.redtassel.regsiter.RTSE;
import mods.flammpfeil.slashblade.client.renderer.CarryType;
import mods.flammpfeil.slashblade.item.SwordType;
import mods.flammpfeil.slashblade.registry.slashblade.EnchantmentDefinition;
import mods.flammpfeil.slashblade.registry.slashblade.PropertiesDefinition;
import mods.flammpfeil.slashblade.registry.slashblade.RenderDefinition;
import mods.flammpfeil.slashblade.registry.slashblade.SlashBladeDefinition;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

public class SlashBladeButilnRegsitry {
    public static final ResourceKey<SlashBladeDefinition> redtassel_slashblade = register("redtassel_slashblade");
    public static void registerAll(BootstapContext<SlashBladeDefinition> bootstrap) {
        bootstrap.register(redtassel_slashblade,new SlashBladeDefinition(

                Redtassel.prefix("redtassel_slashblade"),
                RenderDefinition.Builder.newInstance()
                        .effectColor(16711680)
                        .modelName( Redtassel.prefix("model/katana/redtassel_blade.obj"))
                        .standbyRenderType(CarryType.NINJA)
                        .textureName(Redtassel.prefix("model/katana/redtassel_blade.png"))
                        .build(),
                PropertiesDefinition.Builder.newInstance()
                        .baseAttackModifier(30)
                        .slashArtsType(RTComboAndSA.ThatGoGoGo.getId())
                        .addSpecialEffect(RTSE.SAKURA.getId())
                        .maxDamage(2000)
                        .defaultSwordType(List.of(SwordType.BEWITCHED))
                        .build(),
                List.of(
                        new EnchantmentDefinition(getEnchantmentID(Enchantments.THORNS), 5),
                        new EnchantmentDefinition(getEnchantmentID(Enchantments.POWER_ARROWS),10),
                        new EnchantmentDefinition(getEnchantmentID(Enchantments.FIRE_ASPECT),5),
                        new EnchantmentDefinition(getEnchantmentID(Enchantments.PUNCH_ARROWS),5)
                ),
                Redtassel.Slashblade.getId())
        );
    }
    private static ResourceKey<SlashBladeDefinition> register(String id) {
        return ResourceKey.create(SlashBladeDefinition.REGISTRY_KEY, Redtassel.prefix(id));
    }
    private static ResourceLocation getEnchantmentID(Enchantment enchantment) {
        return ForgeRegistries.ENCHANTMENTS.getKey(enchantment);
    }

}
