package com.alpha.redtassel.data;

import mods.flammpfeil.slashblade.data.builtin.SlashBladeBuiltInRegistry;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.recipe.RequestDefinition;
import mods.flammpfeil.slashblade.recipe.SlashBladeIngredient;
import mods.flammpfeil.slashblade.recipe.SlashBladeShapedRecipeBuilder;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.FinishedRecipe;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.crafting.conditions.IConditionBuilder;

import java.util.function.Consumer;

public class RecipeProvoider extends RecipeProvider implements IConditionBuilder {
    public RecipeProvoider(PackOutput output) {
        super(output);
    }
    protected void buildRecipes(Consumer<FinishedRecipe> consumer){
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeButilnRegsitry.redtassel_slashblade.location())
                .pattern("ABA")
                .pattern("CDC")
                .pattern("AEA")
                .define('A', Tags.Items.STORAGE_BLOCKS_REDSTONE)
                .define('B', SBItems.proudsoul_trapezohedron)
                .define('C', SBItems.proudsoul_sphere)
                .define('D', SlashBladeIngredient.of(
                        RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.location())
                                .proudSoul(10000)
                                .killCount(2000)
                                .refineCount(100)
                                .build()
                ))
                .define('E',Tags.Items.STORAGE_BLOCKS_NETHERITE)
                .unlockedBy(getHasName(SBItems.slashblade), has(SBItems.slashblade)).save(consumer);
    }
}
