package com.alpha.redtassel.entity;

import com.dinzeer.legendreliclib.lib.util.FastMakeEntityUtil;
import mods.flammpfeil.slashblade.entity.Projectile;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

import java.util.List;

public class TheSlashStringEntity extends Projectile {
    private static final EntityDataAccessor<Integer> COLOR= SynchedEntityData.defineId(TheSlashStringEntity.class, EntityDataSerializers.INT);;
    private static final EntityDataAccessor<Float> LIFETIME= SynchedEntityData.defineId(TheSlashStringEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> ROT_X= SynchedEntityData.defineId(TheSlashStringEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ROT_Y= SynchedEntityData.defineId(TheSlashStringEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DAMAGE = SynchedEntityData.defineId(TheSlashStringEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> AllTimeDamage = SynchedEntityData.defineId(TheSlashStringEntity.class, EntityDataSerializers.BOOLEAN);
    public TheSlashStringEntity(EntityType<? extends net.minecraft.world.entity.projectile.Projectile> type, Level level) {
        super(type, level);
    }



    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(COLOR, 3355647);
        this.entityData.define(ROT_X, random.nextInt(-360,360));
        this.entityData.define(ROT_Y, random.nextInt(-360,360));
        this.entityData.define(LIFETIME, 10.0F);
        this.entityData.define(DAMAGE, 1.0F);
        this.entityData.define(AllTimeDamage, false);

    }






    @Override
    public boolean isInvulnerableTo(DamageSource source) {

        return true;
    }
    @Override
    public boolean isPickable() {

        return false;
    }
    @Override
    public void tick() {
        super.tick();
        if(this.tickCount==1){
            if (!this.level().isClientSide()) {
                this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 1.0F);
            }
        }
        if (this.tickCount == this.getLifetime()-10 || this.getAllTimeDamage()){
            damage();
        }
        if (this.tickCount > this.getLifetime()){
            if (!this.level().isClientSide()) {
                this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F,
                        random.nextFloat() * 0.1F + 0.9F);
            }else {
                // 在客户端生成破碎粒子效果
                spawnBreakParticles();
            }
            this.discard();
        }
    }

    private void spawnBreakParticles() {
        // 获取实体的颜色
        int color = this.getColor();
        float r = ((color >> 16) & 0xFF) / 255.0F;
        float g = ((color >> 8) & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;

        // 创建颜色粒子选项
        DustParticleOptions particleOptions = new DustParticleOptions(new Vector3f(r, g, b), 1.0F);

        // 生成多个粒子，模拟破碎效果
        for (int i = 0; i < 15; i++) {
            double offsetX = (random.nextDouble() - 0.5) * 1.5;
            double offsetY = (random.nextDouble() - 0.5) * 1.5;
            double offsetZ = (random.nextDouble() - 0.5) * 1.5;
            double speedX = (random.nextDouble() - 0.5) * 0.2;
            double speedY = (random.nextDouble() - 0.5) * 0.2;
            double speedZ = (random.nextDouble() - 0.5) * 0.2;

            this.level().addParticle(particleOptions,
                    this.getX() + offsetX,
                    this.getY() + offsetY,
                    this.getZ() + offsetZ,
                    speedX, speedY, speedZ);
        }

        for (int i = 0; i < 8; i++) {
            double offsetX = (random.nextDouble() - 0.5);
            double offsetY = (random.nextDouble() - 0.5);
            double offsetZ = (random.nextDouble() - 0.5);

            this.level().addParticle(ParticleTypes.CRIT,
                    this.getX() + offsetX,
                    this.getY() + offsetY,
                    this.getZ() + offsetZ,
                    0, 0, 0);
        }
    }



    public void damage(){
       List<LivingEntity> entityList=   this.level()
               .getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(5));
       for (LivingEntity entity : entityList) {
           if (this.getOwner() instanceof  LivingEntity owner){
               if (entity != owner){


                   FastMakeEntityUtil.FastHurt(entity, owner, getDamage(),DamageType());
               }
           }
       }
    }
    public   ResourceKey<DamageType> DamageType(){
        return DamageTypes.MAGIC;
    }
    public Boolean getAllTimeDamage() {
        return this.getEntityData().get(AllTimeDamage);
    }
    public void setAllTimeDamage(Boolean value) {
        this.getEntityData().set(AllTimeDamage, value);
    }
    public int getRotX() {
        return (Integer)this.getEntityData().get(ROT_X);
    }
    public void setRotX(int value) {
        this.getEntityData().set(ROT_X, value);
    }
    public int getRotY() {
        return (Integer)this.getEntityData().get(ROT_Y);
    }
    public void setRotY(int value) {
        this.getEntityData().set(ROT_Y, value);
    }
    public int getColor() {
        return (Integer)this.getEntityData().get(COLOR);
    }
    public void setColor(int value) {
        this.getEntityData().set(COLOR, value);
    }
    public float getLifetime() {
        return (Float)this.getEntityData().get(LIFETIME);
    }
    public void setLifetime(float value) {
        this.getEntityData().set(LIFETIME, value);
    }
    public float getDamage() {
        return (Float)this.getEntityData().get(DAMAGE);
    }
    public void setDamage(float value) {
        this.getEntityData().set(DAMAGE, value);
    }
}
