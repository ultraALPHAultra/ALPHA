package com.alpha.redtassel.se;

import com.dinzeer.legendreliclib.lib.util.FastMakeEntityUtil;
import com.dinzeer.legendreliclib.lib.util.slashblade.AbstractSpecialEffect;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

public class Sakura extends AbstractSpecialEffect {
    public Sakura() {
        super(20);
    }

    @Override
    public void handleUpdate(SlashBladeEvent.UpdateEvent event, LivingEntity attacker) {
        FastMakeEntityUtil.FastEffect(attacker, MobEffects.DAMAGE_BOOST,3);
    }
    @Override
    public Component getDescription() {
        return Component.translatable(this.getDescriptionId()).withStyle(ChatFormatting.RED);
    }
}
