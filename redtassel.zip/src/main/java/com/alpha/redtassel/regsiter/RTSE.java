package com.alpha.redtassel.regsiter;

import com.alpha.redtassel.Redtassel;
import com.alpha.redtassel.se.Sakura;
import mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class RTSE {
    public static final DeferredRegister<SpecialEffect> SE = DeferredRegister.create(SpecialEffect.REGISTRY_KEY, Redtassel.MODID);
    public static final RegistryObject<SpecialEffect> SAKURA = SE.register("sakura", Sakura::new);
}
