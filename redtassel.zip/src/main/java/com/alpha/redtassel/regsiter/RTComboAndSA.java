package com.alpha.redtassel.regsiter;

import com.alpha.redtassel.Redtassel;
import com.alpha.redtassel.sa.GoGoGo;
import com.alpha.redtassel.sa.TheString;
import com.dinzeer.legendreliclib.lib.util.WaitingTick;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.ability.StunManager;
import mods.flammpfeil.slashblade.init.DefaultResources;
import mods.flammpfeil.slashblade.registry.combo.ComboState;
import mods.flammpfeil.slashblade.slasharts.SlashArts;
import mods.flammpfeil.slashblade.util.AttackManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Function;

import static com.alpha.redtassel.Redtassel.MODID;

public class RTComboAndSA {
    public static final DeferredRegister<SlashArts> SLASH_ARTS =
            DeferredRegister.create(SlashArts.REGISTRY_KEY, MODID);
    public static final DeferredRegister<ComboState> COMBO_STATES =
            DeferredRegister.create(ComboState.REGISTRY_KEY,MODID);









    public static final RegistryObject<ComboState> ALL_REUSE = COMBO_STATES.register
            (
                    "all_reuse",
                    ComboState.Builder.newInstance().startAndEnd(459, 488).priority(50)
                            .motionLoc(DefaultResources.ExMotionLocation).next(entity -> SlashBlade.prefix("none"))
                            .nextOfTimeout(entity -> SlashBlade.prefix("none"))
                            .addTickAction(ComboState.TimeLineTickAction.getBuilder()
                                    .put(0, AttackManager::playQuickSheathSoundAction)
                                    .put(1, (entity)->{
                                        // 创建检测范围（半径10格）
                                        AABB area = new AABB(entity.blockPosition()).inflate(10);

                                        entity.level().getEntitiesOfClass(LivingEntity.class, area).stream()
                                                .filter(e ->
                                                        e != entity && // 排除自己
                                                                !e.isAlliedTo(entity) && // 排除友方
                                                                e.isAlive() // 仅存活目标
                                                )
                                                .forEach(target -> {
                                                    // 造成魔法伤害（无视护甲）
                                                    target.hurt(entity.damageSources().magic(), 100f);

                                                     target.invulnerableTime = 0; // 重置无敌时间（强制造成伤害）
                                                     entity.level().playSound(null, target.getX(), target.getY(), target.getZ(),
                                                             SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0F, 1.0F);
                                                });
                                    })
                                    .build()

                            )
                            .releaseAction(ComboState::releaseActionQuickCharge)::build
            );

    public static final RegistryObject<ComboState> GoGogo = COMBO_STATES.register
            (
                    "xdrive",
                    ComboState.Builder.newInstance().startAndEnd(400, 459).priority(50)
                            .motionLoc(DefaultResources.ExMotionLocation)
                            .next(ComboState.TimeoutNext.buildFromFrame(15, entity -> SlashBlade.prefix("none")))
                            .nextOfTimeout(entity -> Redtassel.prefix("all_reuse"))
                            .addTickAction
                                    (
                                            ComboState.TimeLineTickAction.getBuilder()
                                                    .put(2, (entityIn) -> AttackManager.doSlash(entityIn, -45F, Vec3.ZERO, false, false, 1F))
                                                    .put(3, GoGoGo::dois)
                                                    .put(4, (entityIn) -> AttackManager.doSlash(entityIn, 45F, Vec3.ZERO, false, false, 1F))
                                                    .put(5, (entityIn) ->{

                                                        for (int i = 0; i < 15; i++){
                                                            WaitingTick.schedule(i, ()->{
                                                                AttackManager.doSlash(
                                                                        entityIn,
                                                                        entityIn.getRandom().nextInt(360),
                                                                        Vec3.ZERO,
                                                                        false,
                                                                        false,
                                                                        1F
                                                                );
                                                                TheString.DoSlash(entityIn);
                                                            });
                                                        }

                                                    })
                                                    .put(6, GoGoGo::dois2)
                                                    .put(15, (entityIn) ->{

                                                        for (int i = 0; i < 15; i++){
                                                            WaitingTick.schedule(i, ()->{
                                                                AttackManager.doSlash(
                                                                        entityIn,
                                                                        entityIn.getRandom().nextInt(360),
                                                                        Vec3.ZERO,
                                                                        false,
                                                                        false,
                                                                        1F
                                                                );
                                                                TheString.DoSlash(entityIn);
                                                            });
                                                        }
                                                    })

                                                    .build()
                                    )
                            .addHitEffect(StunManager::setStun)
                            ::build
            );
    public static final RegistryObject<SlashArts> ThatGoGoGo = SLASH_ARTS.register("that_go_go_go",()->new GoGoGoSa((e)->GoGogo.getId()));


    public static class GoGoGoSa extends SlashArts{

        public GoGoGoSa(Function<LivingEntity, ResourceLocation> state) {
            super(state);
        }

        @Override
        public Component getDescription() {
            return Component.translatable(this.getDescriptionId()).withStyle(ChatFormatting.RED);
        }
    }












    public static void regsister(IEventBus eventBus){
        SLASH_ARTS.register(eventBus);
        COMBO_STATES.register(eventBus);
    }


}
