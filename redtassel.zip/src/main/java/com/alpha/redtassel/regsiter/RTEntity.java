package com.alpha.redtassel.regsiter;

import com.alpha.redtassel.entity.TheSlashStringEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import static com.alpha.redtassel.Redtassel.MODID;

public class RTEntity {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES,MODID);
    public static final RegistryObject<EntityType<TheSlashStringEntity>> TheSlashString =
            ENTITIES.register("the_slash_string",
                    () -> EntityType.Builder.of(TheSlashStringEntity::new, MobCategory.MISC)
                            .sized(0.5F, 0.5F) // 碰撞箱大小
                            .clientTrackingRange(4)
                            .updateInterval(1) // 更新间隔
                            .build("the_slash_string"));
}
