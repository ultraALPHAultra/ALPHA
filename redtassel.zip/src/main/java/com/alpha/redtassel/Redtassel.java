package com.alpha.redtassel;

import com.alpha.redtassel.data.RecipeProvoider;
import com.alpha.redtassel.data.SlashBladeButilnRegsitry;
import com.alpha.redtassel.regsiter.RTComboAndSA;
import com.alpha.redtassel.regsiter.RTEntity;
import com.alpha.redtassel.regsiter.RTSE;
import com.mojang.logging.LogUtils;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import mods.flammpfeil.slashblade.registry.slashblade.SlashBladeDefinition;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.data.DatapackBuiltinEntriesProvider;
import net.minecraftforge.data.event.GatherDataEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

import java.util.Set;
import java.util.concurrent.CompletableFuture;

// The value here should match an entry in the META-INF/mods.toml file
@Mod(Redtassel.MODID)
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Redtassel {

    // Define mod id in a common place for everything to reference
    public static final String MODID = "redtassel";
    // Directly reference a slf4j logger
    private static final Logger LOGGER = LogUtils.getLogger();
    public static ResourceLocation prefix(String path) {

        return new ResourceLocation(MODID, path);
    }
    public Redtassel() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        RTComboAndSA.regsister(modEventBus);
        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);
        CREATIVE_MODE_TABS.register(modEventBus);
        RTSE.SE.register(modEventBus);
        RTEntity.ENTITIES.register(modEventBus);
    }
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS
            = DeferredRegister.create(Registries.CREATIVE_MODE_TAB,MODID);  ;
    public static final RegistryObject<CreativeModeTab> Slashblade = CREATIVE_MODE_TABS.register(MODID+"_slashblade",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("item.redtassel.redtassel_slashblade")).icon(() -> {
                        ItemStack stack = new ItemStack(SBItems.slashblade);
                        stack.getCapability(ItemSlashBlade.BLADESTATE).ifPresent(s -> {
                            s.setModel(new ResourceLocation(MODID, "model/katana/redtassel_blade.obj"));
                            s.setTexture(new ResourceLocation(MODID, "model/katana/redtassel_blade.png"));
                        });
                        return stack;
                    })
                    .displayItems((parameters, tabData) -> {

                    })
                    .build());

    @SubscribeEvent
    public static void dataGen(GatherDataEvent event) {
        DataGenerator dataGenerator = event.getGenerator();
        CompletableFuture<HolderLookup.Provider> lookupProvider = event.getLookupProvider();
        PackOutput packOutput = dataGenerator.getPackOutput();

        dataGenerator.addProvider(event.includeServer(), new RecipeProvoider(packOutput));

        final RegistrySetBuilder bladeBuilder = new RegistrySetBuilder()
                .add(SlashBladeDefinition.REGISTRY_KEY,
                        SlashBladeButilnRegsitry::registerAll);
        dataGenerator.addProvider(event.includeServer(),
                new DatapackBuiltinEntriesProvider(packOutput, lookupProvider,bladeBuilder, Set.of(MODID)));
    }

}
