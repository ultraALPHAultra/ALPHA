package com.alpha.redtassel.sa;

import com.alpha.redtassel.entity.TheSlashStringEntity;
import com.alpha.redtassel.regsiter.RTEntity;
import com.dinzeer.legendreliclib.lib.util.slashblade.SlashBladeUtil;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

import java.util.Random;

public class TheString {
    public static void DoSlash(LivingEntity attacker){
        ISlashBladeState state = SlashBladeUtil.getState(attacker.getMainHandItem());
        Level worldIn = attacker.level();
        Random random = new Random();

        double angle = random.nextDouble() * 2 * Math.PI;
        double radius = random.nextDouble() * 5.0;
        double xOffset = radius * Math.cos(angle);
        double zOffset = radius * Math.sin(angle);
        double heightOffset = (Math.random() * 4.0) - 2.0;
        TheSlashStringEntity entity =
                new TheSlashStringEntity(RTEntity.TheSlashString.get(), attacker.level());
        entity.setPos(
                attacker.getX() + xOffset,
                attacker.getY() + 1+heightOffset,
                attacker.getZ() + zOffset
        );

        // 随机选择颜色
        int colorType = random.nextInt(2);
        switch (colorType) {
            case 0:
                entity.setColor(state.getColorCode());
                break;
            case 1:
                entity.setColor(state.getColorCode()*2);
                break;
        }
        entity.setLifetime(11);
        entity.setOwner(attacker);
        entity.setDamage(3);
        worldIn.addFreshEntity(entity);
    }
}
