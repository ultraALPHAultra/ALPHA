package com.alpha.redtassel;

import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.capability.slashblade.SlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import static com.alpha.redtassel.Redtassel.MODID;
import static mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect.isEffective;

@Mod.EventBusSubscriber
public class Event {
    @SubscribeEvent
    public static void onPlayerJoin(LivingHurtEvent event) {
       System.out.println("本次伤害"+event.getAmount());
    }


    @SubscribeEvent
    @OnlyIn(Dist.CLIENT)
    public static void onItemTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        if (stack.getItem() != SBItems.slashblade){
            return;
        }

        if (!hasTran(stack,"item.redtassel.redtassel_blade"))return;
        event.getToolTip().add(Component.translatable("tooltip." + MODID + ".redtassel_blade.line1").withStyle(ChatFormatting.RED));
        event.getToolTip().add(Component.translatable("tooltip." + MODID + ".redtassel_blade.line2").withStyle(ChatFormatting.RED));
        event.getToolTip().add(Component.translatable("tooltip." + MODID + ".redtassel_blade.line3").withStyle(ChatFormatting.RED));
        event.getToolTip().add(Component.translatable("tooltip." + MODID + ".redtassel_blade.line4").withStyle(ChatFormatting.RED));
    }
    public static boolean hasTran(ItemStack stack, String effect) {
        CompoundTag tag = stack.getOrCreateTag(); // 获取或创建NBT标签

        if (tag.contains("bladeState")) { // 检查是否存在ForgeCaps标签
            CompoundTag forgeCaps = tag.getCompound("bladeState");

            if (forgeCaps.contains("translationKey")) { // 检查SpecialEffects标签
                String translationKey = forgeCaps.getString("translationKey"); // 8表示String类型
                if (translationKey.equals(effect)){
                    return true;
                }

            }

        }
        return false; // 没有找到指定的特殊效果
    }
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void PlayerHitIs(SlashBladeEvent.BladeStandAttackEvent event) {
        Entity entity = event.getDamageSource().getEntity();
        if (entity instanceof LivingEntity livingEntity){
        if (livingEntity.getMainHandItem().getItem() ==SBItems.proudsoul_ingot){
            ISlashBladeState state = event.getSlashBladeState();
            if (state.getTranslationKey().equals("item.redtassel.redtassel_blade")){
                event.setCanceled(true);
            }
        }
        }
    }
}
